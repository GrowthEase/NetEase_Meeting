var searchData=
[
  ['editmeeting_37',['editMeeting',['../classnem__sdk__interface_1_1_n_e_pre_meeting_service.html#a7cfcbe3fca63a84858006921883862ec',1,'nem_sdk_interface::NEPreMeetingService']]],
  ['enable_38',['enable',['../structnem__sdk__interface_1_1tag_n_e_meeting_item_live_setting.html#aaf9e9b59dbee7b1724123634bdddad37',1,'nem_sdk_interface::tagNEMeetingItemLiveSetting']]],
  ['enablelive_39',['enableLive',['../structnem__sdk__interface_1_1tag_n_e_meeting_item.html#a7dc97ef28f77213d4c996ef3f87067c9',1,'nem_sdk_interface::tagNEMeetingItem']]],
  ['enablevirtualbackground_40',['enableVirtualBackground',['../classnem__sdk__interface_1_1_n_e_virtual_background_controller.html#a55cae8cd91610f50afa84e578b62516c',1,'nem_sdk_interface::NEVirtualBackgroundController']]],
  ['endtime_41',['endTime',['../structnem__sdk__interface_1_1tag_n_e_meeting_item.html#abf54aa01d244a0300da2d8c45efec3c5',1,'nem_sdk_interface::tagNEMeetingItem']]],
  ['error_2eh_42',['error.h',['../error_8h.html',1,'']]],
  ['error_5fcode_5fcancelled_43',['ERROR_CODE_CANCELLED',['../namespacenem__sdk__interface.html#a7328a07f46550e029c47134fbdf2bbf2a8d3f2d50e33f3c103fba930b357e6202',1,'nem_sdk_interface']]],
  ['error_5fcode_5ffailed_44',['ERROR_CODE_FAILED',['../namespacenem__sdk__interface.html#a7328a07f46550e029c47134fbdf2bbf2a8b6cb71f1df2ed76ecbe17c17bdd2bb7',1,'nem_sdk_interface']]],
  ['error_5fcode_5fmeeting_5fpassword_5ferror_45',['ERROR_CODE_MEETING_PASSWORD_ERROR',['../namespacenem__sdk__interface.html#a7328a07f46550e029c47134fbdf2bbf2aa9bda9ca903d89bc9293a298d43ce6f5',1,'nem_sdk_interface']]],
  ['error_5fcode_5fno_5fauth_46',['ERROR_CODE_NO_AUTH',['../namespacenem__sdk__interface.html#a7328a07f46550e029c47134fbdf2bbf2a55ed32541e428e7de996d662c8046873',1,'nem_sdk_interface']]],
  ['error_5fcode_5fnot_5fimplemented_47',['ERROR_CODE_NOT_IMPLEMENTED',['../namespacenem__sdk__interface.html#a7328a07f46550e029c47134fbdf2bbf2a4d3e814b781b6ee5767cc3c28a15d32d',1,'nem_sdk_interface']]],
  ['error_5fcode_5fsdk_5fservice_5fnotsupport_48',['ERROR_CODE_SDK_SERVICE_NOTSUPPORT',['../namespacenem__sdk__interface.html#a7328a07f46550e029c47134fbdf2bbf2afcfe823af10118d13819ef9d7234ad34',1,'nem_sdk_interface']]],
  ['error_5fcode_5fsdk_5funinitialize_49',['ERROR_CODE_SDK_UNINITIALIZE',['../namespacenem__sdk__interface.html#a7328a07f46550e029c47134fbdf2bbf2a7449427f31b9157cd5204ba463743cc9',1,'nem_sdk_interface']]],
  ['error_5fcode_5fsuccess_50',['ERROR_CODE_SUCCESS',['../namespacenem__sdk__interface.html#a7328a07f46550e029c47134fbdf2bbf2acad2f6eb2f8ad216702d9edcd7fc9ee1',1,'nem_sdk_interface']]],
  ['error_5fcode_5funexpected_51',['ERROR_CODE_UNEXPECTED',['../namespacenem__sdk__interface.html#a7328a07f46550e029c47134fbdf2bbf2a0af510ce3d4b165d6ac4b250443d3ca6',1,'nem_sdk_interface']]],
  ['exception_2eh_52',['exception.h',['../exception_8h.html',1,'']]],
  ['exception_5fdefine_2eh_53',['exception_define.h',['../exception__define_8h.html',1,'']]],
  ['exceptioncode_54',['ExceptionCode',['../classnem__sdk__interface_1_1_n_e_exception.html#a557d8d776ceb85e5d38cf2bebf87768d',1,'nem_sdk_interface::NEException::ExceptionCode() const'],['../classnem__sdk__interface_1_1_n_e_exception.html#a93b6040727586219fad5595776dc38c7',1,'nem_sdk_interface::NEException::ExceptionCode(NEExceptionCode code)']]],
  ['exceptionmessage_55',['ExceptionMessage',['../classnem__sdk__interface_1_1_n_e_exception.html#a4edeecd78a32f087f117773b5dbefdc0',1,'nem_sdk_interface::NEException::ExceptionMessage() const'],['../classnem__sdk__interface_1_1_n_e_exception.html#aed0d9ed7165cd8dd3d26980fcab51f57',1,'nem_sdk_interface::NEException::ExceptionMessage(const std::string &amp;msg)']]],
  ['extradata_56',['extraData',['../structnem__sdk__interface_1_1tag_n_e_meeting_info.html#aaae266c435755df3e0d048866bfdba5d',1,'nem_sdk_interface::tagNEMeetingInfo::extraData()'],['../classnem__sdk__interface_1_1_n_e_start_meeting_params.html#aca8da22c11e2ebe86feba98a68c823c7',1,'nem_sdk_interface::NEStartMeetingParams::extraData()'],['../structnem__sdk__interface_1_1tag_n_e_meeting_item.html#a97b056678aad2b22ab6e8651ab6c13c3',1,'nem_sdk_interface::tagNEMeetingItem::extraData()']]]
];
