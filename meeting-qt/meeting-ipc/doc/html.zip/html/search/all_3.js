var searchData=
[
  ['defaultwindowmode_34',['defaultWindowMode',['../classnem__sdk__interface_1_1_n_e_meeting_options.html#ab92833ff734e7c51e59750bd7baaa8ee',1,'nem_sdk_interface::NEMeetingOptions']]],
  ['displayname_35',['displayName',['../classnem__sdk__interface_1_1_n_e_meeting_params.html#af754fe42f6f808f0318bbada698a067f',1,'nem_sdk_interface::NEMeetingParams']]],
  ['duration_36',['duration',['../structnem__sdk__interface_1_1tag_n_e_meeting_info.html#a78e5fc9d2a0e62eea4c3911405f69604',1,'nem_sdk_interface::tagNEMeetingInfo']]]
];
