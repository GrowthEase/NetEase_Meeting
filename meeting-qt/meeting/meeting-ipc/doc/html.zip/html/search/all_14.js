var searchData=
[
  ['uninitialize_467',['unInitialize',['../classnem__sdk__interface_1_1_n_e_meeting_kit.html#a11e398da5794cee94cc8761f181d42fc',1,'nem_sdk_interface::NEMeetingKit']]],
  ['unpubaudioonmute_468',['unpubAudioOnMute',['../classnem__sdk__interface_1_1_n_e_meeting_options.html#a6c9e63039263aedd56162a4a6ff60fe1',1,'nem_sdk_interface::NEMeetingOptions']]],
  ['unregisterschedulemeetingstatuslistener_469',['unRegisterScheduleMeetingStatusListener',['../classnem__sdk__interface_1_1_n_e_pre_meeting_service.html#a9d8f6ef5172b66ba7c5e87d88ee07c76',1,'nem_sdk_interface::NEPreMeetingService']]],
  ['updatetime_470',['updateTime',['../structnem__sdk__interface_1_1tag_n_e_meeting_item.html#a000074d4c58338324a125836e149e31d',1,'nem_sdk_interface::tagNEMeetingItem']]],
  ['usemeetingchatroomaslivechatroom_471',['useMeetingChatRoomAsLiveChatRoom',['../structnem__sdk__interface_1_1tag_n_e_meeting_item_live_setting.html#a5fdb2ef21101b8b8477cc5c5e9c7c964',1,'nem_sdk_interface::tagNEMeetingItemLiveSetting']]],
  ['userid_472',['userId',['../structnem__sdk__interface_1_1tag_n_e_in_meeting_user_info.html#a89575a71e2da72bf2f1e7b8efe4a6996',1,'nem_sdk_interface::tagNEInMeetingUserInfo']]],
  ['userlist_473',['userList',['../structnem__sdk__interface_1_1tag_n_e_meeting_info.html#a12643549677a1e5122f02b70322bbe42',1,'nem_sdk_interface::tagNEMeetingInfo::userList()'],['../structnem__sdk__interface_1_1tag_n_e_meeting_role_configuration.html#a358685d00e1b3a5d679871c0bd37856b',1,'nem_sdk_interface::tagNEMeetingRoleConfiguration::userList()']]],
  ['username_474',['userName',['../structnem__sdk__interface_1_1tag_n_e_in_meeting_user_info.html#ad6e3d249f3eb80828768ea021ea536ad',1,'nem_sdk_interface::tagNEInMeetingUserInfo']]],
  ['username_475',['username',['../structnem__sdk__interface_1_1tag_account_info.html#aee86cfff2eb461227b5883cfaee5dbf2',1,'nem_sdk_interface::tagAccountInfo']]],
  ['using_5fns_5fnnem_5fsdk_5finterface_476',['USING_NS_NNEM_SDK_INTERFACE',['../build__config_8h.html#ae0f492f37229a40a404e8108e0903fed',1,'build_config.h']]]
];
