var searchData=
[
  ['website_480',['webSite',['../structnem__sdk__interface_1_1tag_n_e_meeting_item_live_setting.html#aee1dac256a406186c2a5e6c4bf93bebf',1,'nem_sdk_interface::tagNEMeetingItemLiveSetting']]],
  ['whiteboard_5fmode_481',['WHITEBOARD_MODE',['../namespacenem__sdk__interface.html#a34b1f1391c9af19666ae97f921de1958aece6819d42e8a5d59151be9b12a3e769',1,'nem_sdk_interface']]]
];
