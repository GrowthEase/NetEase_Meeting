var searchData=
[
  ['website_806',['webSite',['../structnem__sdk__interface_1_1tag_n_e_meeting_item_live_setting.html#aee1dac256a406186c2a5e6c4bf93bebf',1,'nem_sdk_interface::tagNEMeetingItemLiveSetting']]]
];
