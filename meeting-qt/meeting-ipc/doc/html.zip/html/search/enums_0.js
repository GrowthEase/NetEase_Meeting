var searchData=
[
  ['audiodeviceautoselecttype_796',['AudioDeviceAutoSelectType',['../namespacenem__sdk__interface.html#a3d0058e503ebe1c0f6aac4ffbce56d68',1,'nem_sdk_interface']]],
  ['audioquality_797',['AudioQuality',['../namespacenem__sdk__interface.html#af345decf7aa07c546067660703ee66c9',1,'nem_sdk_interface']]]
];
