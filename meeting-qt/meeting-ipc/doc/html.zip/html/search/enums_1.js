var searchData=
[
  ['localvideoresolution_798',['LocalVideoResolution',['../namespacenem__sdk__interface.html#abeb0ccc48e9d0db84e8a6885a7771f31',1,'nem_sdk_interface']]]
];
