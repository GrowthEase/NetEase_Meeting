var searchData=
[
  ['liveurl_705',['liveUrl',['../structnem__sdk__interface_1_1tag_n_e_meeting_item.html#aefdfb95bab62dd9c4c70c90c016b6b91',1,'nem_sdk_interface::tagNEMeetingItem']]],
  ['livewebaccesscontrollevel_706',['liveWebAccessControlLevel',['../structnem__sdk__interface_1_1tag_n_e_meeting_item.html#a9854704863cf28b0b09cf12350120b53',1,'nem_sdk_interface::tagNEMeetingItem']]],
  ['logintype_707',['loginType',['../structnem__sdk__interface_1_1tag_account_info.html#a836fb941e73a2af2b47336ac93b90a60',1,'nem_sdk_interface::tagAccountInfo']]]
];
