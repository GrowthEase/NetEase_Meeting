var searchData=
[
  ['rolebinds_730',['roleBinds',['../classnem__sdk__interface_1_1_n_e_start_meeting_params.html#a5cc72b1fa885945d2ec86425d0145eea',1,'nem_sdk_interface::NEStartMeetingParams::roleBinds()'],['../structnem__sdk__interface_1_1tag_n_e_meeting_item.html#ab4d8e9b6d98182c225ae3e3a697645d8',1,'nem_sdk_interface::tagNEMeetingItem::roleBinds()']]],
  ['roletype_731',['roleType',['../structnem__sdk__interface_1_1tag_n_e_meeting_role_configuration.html#a537e45fc6e60d22530a81021c8c41614',1,'nem_sdk_interface::tagNEMeetingRoleConfiguration::roleType()'],['../classnem__sdk__interface_1_1_n_e_meeting_params.html#ab48be60bc73a918517f519afc185241b',1,'nem_sdk_interface::NEMeetingParams::roleType()']]],
  ['roletypes_732',['roleTypes',['../structnem__sdk__interface_1_1tag_n_e_meeting_scene.html#a5347de030021b40ee0ac39c49422f6c7',1,'nem_sdk_interface::tagNEMeetingScene']]]
];
