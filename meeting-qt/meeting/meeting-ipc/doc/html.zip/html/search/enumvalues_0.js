var searchData=
[
  ['audiodeviceautoselecttype_5favailable_872',['AudioDeviceAutoSelectType_Available',['../namespacenem__sdk__interface.html#a3d0058e503ebe1c0f6aac4ffbce56d68a1b4852c8244ea0f14c03cf5ab67aa842',1,'nem_sdk_interface']]],
  ['audiodeviceautoselecttype_5fdefault_873',['AudioDeviceAutoSelectType_Default',['../namespacenem__sdk__interface.html#a3d0058e503ebe1c0f6aac4ffbce56d68ace43e5ae4b7c8f8d7324ee8684758f00',1,'nem_sdk_interface']]],
  ['audioquality_5fmusic_874',['AudioQuality_Music',['../namespacenem__sdk__interface.html#af345decf7aa07c546067660703ee66c9ab93f69e24f0bb5b38522925d5e89cfef',1,'nem_sdk_interface']]],
  ['audioquality_5ftalk_875',['AudioQuality_Talk',['../namespacenem__sdk__interface.html#af345decf7aa07c546067660703ee66c9aaac0acf1ce022cf204e2ac0dbe448634',1,'nem_sdk_interface']]]
];
