var searchData=
[
  ['full_5fmore_5fmenu_5fitems_5f_732',['full_more_menu_items_',['../classnem__sdk__interface_1_1_n_e_meeting_options.html#aec93632b8f3f27e5c80bc38e96d826c2',1,'nem_sdk_interface::NEMeetingOptions']]],
  ['full_5ftoolbar_5fmenu_5fitems_5f_733',['full_toolbar_menu_items_',['../classnem__sdk__interface_1_1_n_e_meeting_options.html#a842abcd8c34bd8d7a33417882b5dda14',1,'nem_sdk_interface::NEMeetingOptions']]]
];
