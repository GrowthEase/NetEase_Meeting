var searchData=
[
  ['tag_796',['tag',['../structnem__sdk__interface_1_1tag_n_e_in_meeting_user_info.html#abbc97a7b225b694c9351143ba6b5d507',1,'nem_sdk_interface::tagNEInMeetingUserInfo::tag()'],['../classnem__sdk__interface_1_1_n_e_meeting_params.html#a97330ded5319b52675863dfecf1487b5',1,'nem_sdk_interface::NEMeetingParams::tag()']]],
  ['title_797',['title',['../structnem__sdk__interface_1_1tag_n_e_meeting_item_live_setting.html#a3c78e03bb488c33e69765349efb25e70',1,'nem_sdk_interface::tagNEMeetingItemLiveSetting']]],
  ['type_798',['type',['../structnem__sdk__interface_1_1tag_n_e_meeting_control.html#a45ec380af2da56751a7822b6c66f6837',1,'nem_sdk_interface::tagNEMeetingControl']]]
];
