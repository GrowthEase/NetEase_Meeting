var searchData=
[
  ['registerschedulemeetingstatuslistener_381',['registerScheduleMeetingStatusListener',['../classnem__sdk__interface_1_1_n_e_pre_meeting_service.html#aefd12c562778712293f1f2218aa40312',1,'nem_sdk_interface::NEPreMeetingService']]],
  ['remotevideoresolution_382',['RemoteVideoResolution',['../namespacenem__sdk__interface.html#a2675cb3e058acb583bb2456c9dfacb92',1,'nem_sdk_interface']]],
  ['remotevideoresolution_5fdefault_383',['RemoteVideoResolution_Default',['../namespacenem__sdk__interface.html#a2675cb3e058acb583bb2456c9dfacb92ae04ef58a9d4b8c1c56f97eb7ec769f88',1,'nem_sdk_interface']]],
  ['remotevideoresolution_5fhd_384',['RemoteVideoResolution_HD',['../namespacenem__sdk__interface.html#a2675cb3e058acb583bb2456c9dfacb92af467699c853554ed50277440e156c76d',1,'nem_sdk_interface']]],
  ['removeauthlistener_385',['removeAuthListener',['../classnem__sdk__interface_1_1_n_e_auth_service.html#a5b5d3dca57f19b989272108fc0185895',1,'nem_sdk_interface::NEAuthService']]],
  ['rolebinds_386',['roleBinds',['../classnem__sdk__interface_1_1_n_e_start_meeting_params.html#a5cc72b1fa885945d2ec86425d0145eea',1,'nem_sdk_interface::NEStartMeetingParams::roleBinds()'],['../structnem__sdk__interface_1_1tag_n_e_meeting_item.html#ab4d8e9b6d98182c225ae3e3a697645d8',1,'nem_sdk_interface::tagNEMeetingItem::roleBinds()']]],
  ['roletype_387',['roleType',['../structnem__sdk__interface_1_1tag_n_e_meeting_role_configuration.html#a537e45fc6e60d22530a81021c8c41614',1,'nem_sdk_interface::tagNEMeetingRoleConfiguration::roleType()'],['../classnem__sdk__interface_1_1_n_e_meeting_params.html#ab48be60bc73a918517f519afc185241b',1,'nem_sdk_interface::NEMeetingParams::roleType()']]],
  ['roletypes_388',['roleTypes',['../structnem__sdk__interface_1_1tag_n_e_meeting_scene.html#a5347de030021b40ee0ac39c49422f6c7',1,'nem_sdk_interface::tagNEMeetingScene']]]
];
