var searchData=
[
  ['joinmeeting_135',['joinMeeting',['../classnem__sdk__interface_1_1_n_e_meeting_service.html#ad156ce07c1030ebedf29baa9d48c9fa0',1,'nem_sdk_interface::NEMeetingService']]],
  ['jointimeout_136',['joinTimeout',['../classnem__sdk__interface_1_1_n_e_meeting_options.html#ad8b8e6dff493dbe12c57bc697b87daed',1,'nem_sdk_interface::NEMeetingOptions']]]
];
