var searchData=
[
  ['initialize_570',['initialize',['../classnem__sdk__interface_1_1_n_e_meeting_kit.html#a03aa3e5c09e9ddfe365bd63f88eec15e',1,'nem_sdk_interface::NEMeetingKit']]],
  ['isbeautyfaceenabled_571',['isBeautyFaceEnabled',['../classnem__sdk__interface_1_1_n_e_beauty_face_controller.html#a48cb603f241c04d523ca5b88dd60a105',1,'nem_sdk_interface::NEBeautyFaceController']]],
  ['iscloudrecordenabled_572',['isCloudRecordEnabled',['../classnem__sdk__interface_1_1_n_e_record_controller.html#a12969423e8d2143b84f03ab2f83715d0',1,'nem_sdk_interface::NERecordController']]],
  ['isinitialized_573',['isInitialized',['../classnem__sdk__interface_1_1_n_e_meeting_kit.html#a92f7f7fff7ec229380547c891ff25e48',1,'nem_sdk_interface::NEMeetingKit']]],
  ['isliveenabled_574',['isLiveEnabled',['../classnem__sdk__interface_1_1_n_e_live_controller.html#aace5d08b5b0faf8e74d57766b3f045cd',1,'nem_sdk_interface::NELiveController']]],
  ['ismyaudiodeviceautoselecttype_575',['isMyAudioDeviceAutoSelectType',['../classnem__sdk__interface_1_1_n_e_audio_controller.html#a5b955182e39a4c532ab318324ae56a89',1,'nem_sdk_interface::NEAudioController']]],
  ['ismyaudioechocancellation_576',['isMyAudioEchoCancellation',['../classnem__sdk__interface_1_1_n_e_audio_controller.html#a7b5bd01fa776f550095c89ea2ed8504a',1,'nem_sdk_interface::NEAudioController']]],
  ['ismyaudioenablestereo_577',['isMyAudioEnableStereo',['../classnem__sdk__interface_1_1_n_e_audio_controller.html#aaee2a5af619c50b66be99f8898ebad61',1,'nem_sdk_interface::NEAudioController']]],
  ['ismyaudiovolumeautoadjust_578',['isMyAudioVolumeAutoAdjust',['../classnem__sdk__interface_1_1_n_e_audio_controller.html#a2e47fd95d59996149b6c4e682c77d99a',1,'nem_sdk_interface::NEAudioController']]],
  ['issoftwarerender_579',['isSoftwareRender',['../classnem__sdk__interface_1_1_n_e_meeting_kit.html#a0f8c07026ea855699f050e9f790be168',1,'nem_sdk_interface::NEMeetingKit']]],
  ['isturnonmyaudioainswheninmeetingenabled_580',['isTurnOnMyAudioAINSWhenInMeetingEnabled',['../classnem__sdk__interface_1_1_n_e_audio_controller.html#a4dae0c341171f44aca0e1d4d3fc3856b',1,'nem_sdk_interface::NEAudioController']]],
  ['isturnonmyaudiowhenjoinmeetingenabled_581',['isTurnOnMyAudioWhenJoinMeetingEnabled',['../classnem__sdk__interface_1_1_n_e_audio_controller.html#a7c3cfa30cba096469be2962ae7affd11',1,'nem_sdk_interface::NEAudioController']]],
  ['isturnonmyvideowhenjoinmeetingenabled_582',['isTurnOnMyVideoWhenJoinMeetingEnabled',['../classnem__sdk__interface_1_1_n_e_video_controller.html#a434ca10d221b8c867e35e55dd4a6b31d',1,'nem_sdk_interface::NEVideoController']]],
  ['isvirtualbackgroundenabled_583',['isVirtualBackgroundEnabled',['../classnem__sdk__interface_1_1_n_e_virtual_background_controller.html#abf6b266c05f572d6d947367c73900389',1,'nem_sdk_interface::NEVirtualBackgroundController']]],
  ['iswhiteboardenabled_584',['isWhiteboardEnabled',['../classnem__sdk__interface_1_1_n_e_whiteboard_controller.html#aae7d4efe5bd0730e9ca16cf0d8889519',1,'nem_sdk_interface::NEWhiteboardController']]]
];
