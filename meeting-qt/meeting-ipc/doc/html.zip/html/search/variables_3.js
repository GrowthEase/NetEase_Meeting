var searchData=
[
  ['enable_677',['enable',['../structnem__sdk__interface_1_1tag_n_e_meeting_item_live_setting.html#aaf9e9b59dbee7b1724123634bdddad37',1,'nem_sdk_interface::tagNEMeetingItemLiveSetting']]],
  ['enablelive_678',['enableLive',['../structnem__sdk__interface_1_1tag_n_e_meeting_item.html#a7dc97ef28f77213d4c996ef3f87067c9',1,'nem_sdk_interface::tagNEMeetingItem']]],
  ['endtime_679',['endTime',['../structnem__sdk__interface_1_1tag_n_e_meeting_item.html#abf54aa01d244a0300da2d8c45efec3c5',1,'nem_sdk_interface::tagNEMeetingItem']]],
  ['extradata_680',['extraData',['../structnem__sdk__interface_1_1tag_n_e_meeting_info.html#aaae266c435755df3e0d048866bfdba5d',1,'nem_sdk_interface::tagNEMeetingInfo::extraData()'],['../classnem__sdk__interface_1_1_n_e_start_meeting_params.html#aca8da22c11e2ebe86feba98a68c823c7',1,'nem_sdk_interface::NEStartMeetingParams::extraData()'],['../structnem__sdk__interface_1_1tag_n_e_meeting_item.html#a97b056678aad2b22ab6e8651ab6c13c3',1,'nem_sdk_interface::tagNEMeetingItem::extraData()']]]
];
