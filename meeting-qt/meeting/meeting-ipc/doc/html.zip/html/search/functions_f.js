var searchData=
[
  ['uninitialize_704',['unInitialize',['../classnem__sdk__interface_1_1_n_e_meeting_kit.html#a11e398da5794cee94cc8761f181d42fc',1,'nem_sdk_interface::NEMeetingKit']]],
  ['unregisterschedulemeetingstatuslistener_705',['unRegisterScheduleMeetingStatusListener',['../classnem__sdk__interface_1_1_n_e_pre_meeting_service.html#a9d8f6ef5172b66ba7c5e87d88ee07c76',1,'nem_sdk_interface::NEPreMeetingService']]]
];
