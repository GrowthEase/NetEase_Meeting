var indexSectionsWithContent =
{
  0: "abcdefghijklmnopqrstuvw~产创弃",
  1: "fnt",
  2: "n",
  3: "abcefmnps",
  4: "acefgijlnopqrstu~",
  5: "acdefhijklmnprstuw",
  6: "an",
  7: "almnrst",
  8: "acehklmnrsvw",
  9: "nu",
  10: "创",
  11: "产弃"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "enums",
  8: "enumvalues",
  9: "defines",
  10: "groups",
  11: "pages"
};

var indexSectionLabels =
{
  0: "全部",
  1: "类",
  2: "命名空间",
  3: "文件",
  4: "函数",
  5: "变量",
  6: "类型定义",
  7: "枚举",
  8: "枚举值",
  9: "宏定义",
  10: "组",
  11: "页"
};

