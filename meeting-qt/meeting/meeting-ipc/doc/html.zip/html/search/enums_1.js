var searchData=
[
  ['localvideoframerate_853',['LocalVideoFramerate',['../namespacenem__sdk__interface.html#a723d279ab87b6c6690cc1b186b0fc148',1,'nem_sdk_interface']]],
  ['localvideoresolution_854',['LocalVideoResolution',['../namespacenem__sdk__interface.html#abeb0ccc48e9d0db84e8a6885a7771f31',1,'nem_sdk_interface']]]
];
