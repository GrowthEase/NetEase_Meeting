var searchData=
[
  ['remotevideoresolution_5fdefault_959',['RemoteVideoResolution_Default',['../namespacenem__sdk__interface.html#a2675cb3e058acb583bb2456c9dfacb92ae04ef58a9d4b8c1c56f97eb7ec769f88',1,'nem_sdk_interface']]],
  ['remotevideoresolution_5fhd_960',['RemoteVideoResolution_HD',['../namespacenem__sdk__interface.html#a2675cb3e058acb583bb2456c9dfacb92af467699c853554ed50277440e156c76d',1,'nem_sdk_interface']]]
];
