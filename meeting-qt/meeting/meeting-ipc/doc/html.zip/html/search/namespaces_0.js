var searchData=
[
  ['nem_5fsdk_5finterface_536',['nem_sdk_interface',['../namespacenem__sdk__interface.html',1,'']]]
];
