var searchData=
[
  ['cloudrecordon_670',['cloudRecordOn',['../structnem__sdk__interface_1_1tag_n_e_meeting_item_setting.html#ac5f59bd0f32a16ead66e9ac476a67803',1,'nem_sdk_interface::tagNEMeetingItemSetting']]],
  ['code_671',['code',['../structnem__sdk__interface_1_1tag_n_e_meeting_scene.html#a5e04ab0365dad3f5ea8ac38f4438fbde',1,'nem_sdk_interface::tagNEMeetingScene']]],
  ['controls_672',['controls',['../classnem__sdk__interface_1_1_n_e_start_meeting_params.html#a376929ffafc0015c56885abafa498e75',1,'nem_sdk_interface::NEStartMeetingParams::controls()'],['../structnem__sdk__interface_1_1tag_n_e_meeting_item_setting.html#a779fffe5d59cdbcfc0a5c407acb9ea8d',1,'nem_sdk_interface::tagNEMeetingItemSetting::controls()']]],
  ['createtime_673',['createTime',['../structnem__sdk__interface_1_1tag_n_e_meeting_item.html#a6f2ab7310984fc82ee546122016235a9',1,'nem_sdk_interface::tagNEMeetingItem']]]
];
