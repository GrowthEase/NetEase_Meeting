var searchData=
[
  ['settingchangtype_5faudio_961',['SettingChangType_Audio',['../namespacenem__sdk__interface.html#aa501e41fc5b939266bb612c954c17ab9a11d55f160a0d19437b8d55e0292e7b47',1,'nem_sdk_interface']]],
  ['settingchangtype_5faudioains_962',['SettingChangType_AudioAINS',['../namespacenem__sdk__interface.html#aa501e41fc5b939266bb612c954c17ab9a5c4b0437b7215eceedc3e409923b640d',1,'nem_sdk_interface']]],
  ['settingchangtype_5faudioechocancellation_963',['SettingChangType_AudioEchoCancellation',['../namespacenem__sdk__interface.html#aa501e41fc5b939266bb612c954c17ab9a2b058ad2079956cba7795b618abc81b9',1,'nem_sdk_interface']]],
  ['settingchangtype_5faudioenablestereo_964',['SettingChangType_AudioEnableStereo',['../namespacenem__sdk__interface.html#aa501e41fc5b939266bb612c954c17ab9a9013e25b357edd0766980a444fd33bfa',1,'nem_sdk_interface']]],
  ['settingchangtype_5faudioquality_965',['SettingChangType_AudioQuality',['../namespacenem__sdk__interface.html#aa501e41fc5b939266bb612c954c17ab9a2566b2494e902a170e0f5491fc000588',1,'nem_sdk_interface']]],
  ['settingchangtype_5faudiovolumeautoadjust_966',['SettingChangType_AudioVolumeAutoAdjust',['../namespacenem__sdk__interface.html#aa501e41fc5b939266bb612c954c17ab9abd33faffd66a159e6fc02c8b35264874',1,'nem_sdk_interface']]],
  ['settingchangtype_5fmyvideoresolution_967',['SettingChangType_MyVideoResolution',['../namespacenem__sdk__interface.html#aa501e41fc5b939266bb612c954c17ab9a7e334ffa5d9fe44a9fcd9fd814d35b83',1,'nem_sdk_interface']]],
  ['settingchangtype_5fother_968',['SettingChangType_Other',['../namespacenem__sdk__interface.html#aa501e41fc5b939266bb612c954c17ab9a866d3344315a6cc6d1b109aa60e27781',1,'nem_sdk_interface']]],
  ['settingchangtype_5fremotevideoresolution_969',['SettingChangType_RemoteVideoResolution',['../namespacenem__sdk__interface.html#aa501e41fc5b939266bb612c954c17ab9add05bcdd496575cb9b54b7ed0cd2f665',1,'nem_sdk_interface']]],
  ['settingchangtype_5fvideo_970',['SettingChangType_Video',['../namespacenem__sdk__interface.html#aa501e41fc5b939266bb612c954c17ab9a8d4c3d10738ae7c4bda075e3ddca4382',1,'nem_sdk_interface']]]
];
