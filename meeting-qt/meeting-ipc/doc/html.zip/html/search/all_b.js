var searchData=
[
  ['leavemeeting_152',['leaveMeeting',['../classnem__sdk__interface_1_1_n_e_meeting_service.html#a225478f1e4e5953249361a1437874d1b',1,'nem_sdk_interface::NEMeetingService']]],
  ['live_5faccess_5fapp_5ftoken_153',['LIVE_ACCESS_APP_TOKEN',['../namespacenem__sdk__interface.html#ac2a760d29e1855fc4243d7d4d9d1fcb1acc754d778c8baf5a19473c0148a10bd0',1,'nem_sdk_interface']]],
  ['live_5faccess_5fnormal_154',['LIVE_ACCESS_NORMAL',['../namespacenem__sdk__interface.html#ac2a760d29e1855fc4243d7d4d9d1fcb1ac1173c92481e8ea0d7817d3b23168087',1,'nem_sdk_interface']]],
  ['live_5faccess_5ftoken_155',['LIVE_ACCESS_TOKEN',['../namespacenem__sdk__interface.html#ac2a760d29e1855fc4243d7d4d9d1fcb1a976f468fea2b2a2eef793d450eb6c856',1,'nem_sdk_interface']]],
  ['liveurl_156',['liveUrl',['../structnem__sdk__interface_1_1tag_n_e_meeting_item.html#aefdfb95bab62dd9c4c70c90c016b6b91',1,'nem_sdk_interface::tagNEMeetingItem']]],
  ['livewebaccesscontrollevel_157',['liveWebAccessControlLevel',['../structnem__sdk__interface_1_1tag_n_e_meeting_item.html#a9854704863cf28b0b09cf12350120b53',1,'nem_sdk_interface::tagNEMeetingItem']]],
  ['localvideoresolution_158',['LocalVideoResolution',['../namespacenem__sdk__interface.html#abeb0ccc48e9d0db84e8a6885a7771f31',1,'nem_sdk_interface']]],
  ['localvideoresolution_5f1080p_159',['LocalVideoResolution_1080P',['../namespacenem__sdk__interface.html#abeb0ccc48e9d0db84e8a6885a7771f31a6fb9204e697b0e8ba605502a01df7abf',1,'nem_sdk_interface']]],
  ['localvideoresolution_5f480p_160',['LocalVideoResolution_480P',['../namespacenem__sdk__interface.html#abeb0ccc48e9d0db84e8a6885a7771f31a92cb725dbbf19c4c04a19958b3a38dc4',1,'nem_sdk_interface']]],
  ['localvideoresolution_5f720p_161',['LocalVideoResolution_720P',['../namespacenem__sdk__interface.html#abeb0ccc48e9d0db84e8a6885a7771f31a7878282e1986cdce8bbf153d03337be0',1,'nem_sdk_interface']]],
  ['loggerlevel_162',['LoggerLevel',['../classnem__sdk__interface_1_1_n_e_logger_config.html#a11be7c960a0fc301a832340e3227146d',1,'nem_sdk_interface::NELoggerConfig::LoggerLevel() const'],['../classnem__sdk__interface_1_1_n_e_logger_config.html#a7472f16e01186158e00c4178c869fdea',1,'nem_sdk_interface::NELoggerConfig::LoggerLevel(NELogLevel level)']]],
  ['loggerpath_163',['LoggerPath',['../classnem__sdk__interface_1_1_n_e_logger_config.html#af2bdae9c86e8c63334f2330b9367ca1d',1,'nem_sdk_interface::NELoggerConfig::LoggerPath() const'],['../classnem__sdk__interface_1_1_n_e_logger_config.html#a54fbaea50ea38a04352e65c1332539da',1,'nem_sdk_interface::NELoggerConfig::LoggerPath(const std::string &amp;path)']]],
  ['login_164',['login',['../classnem__sdk__interface_1_1_n_e_auth_service.html#a7c91be1a28f68f2edd222182e9da11f3',1,'nem_sdk_interface::NEAuthService::login(const std::string &amp;accountId, const std::string &amp;token, const NEAuthLoginCallback &amp;cb)=0'],['../classnem__sdk__interface_1_1_n_e_auth_service.html#a9b6cc29a1c34de6c359767a03d8e4d35',1,'nem_sdk_interface::NEAuthService::login(const std::string &amp;appKey, const std::string &amp;accountId, const std::string &amp;token, const NEAuthLoginCallback &amp;cb)=0']]],
  ['loginanonymous_165',['loginAnonymous',['../classnem__sdk__interface_1_1_n_e_auth_service.html#a42a6c4471fedb9e0b2a3d98ea7aba847',1,'nem_sdk_interface::NEAuthService']]],
  ['logintype_166',['loginType',['../structnem__sdk__interface_1_1tag_account_info.html#a836fb941e73a2af2b47336ac93b90a60',1,'nem_sdk_interface::tagAccountInfo']]],
  ['loginwithnemeeting_167',['loginWithNEMeeting',['../classnem__sdk__interface_1_1_n_e_auth_service.html#af9187c998ead4568f8378cc6d9dafbe6',1,'nem_sdk_interface::NEAuthService']]],
  ['loginwithssotoken_168',['loginWithSSOToken',['../classnem__sdk__interface_1_1_n_e_auth_service.html#a3a560c8c530e493aa8fd2d289e26237c',1,'nem_sdk_interface::NEAuthService']]],
  ['logout_169',['logout',['../classnem__sdk__interface_1_1_n_e_auth_service.html#a66aecf37eea31d59fa81d47d305521e0',1,'nem_sdk_interface::NEAuthService']]]
];
