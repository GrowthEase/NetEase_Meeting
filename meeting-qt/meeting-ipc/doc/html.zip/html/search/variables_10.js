var searchData=
[
  ['updatetime_747',['updateTime',['../structnem__sdk__interface_1_1tag_n_e_meeting_item.html#a000074d4c58338324a125836e149e31d',1,'nem_sdk_interface::tagNEMeetingItem']]],
  ['usemeetingchatroomaslivechatroom_748',['useMeetingChatRoomAsLiveChatRoom',['../structnem__sdk__interface_1_1tag_n_e_meeting_item_live_setting.html#a5fdb2ef21101b8b8477cc5c5e9c7c964',1,'nem_sdk_interface::tagNEMeetingItemLiveSetting']]],
  ['userid_749',['userId',['../structnem__sdk__interface_1_1tag_n_e_in_meeting_user_info.html#a89575a71e2da72bf2f1e7b8efe4a6996',1,'nem_sdk_interface::tagNEInMeetingUserInfo']]],
  ['userlist_750',['userList',['../structnem__sdk__interface_1_1tag_n_e_meeting_info.html#a12643549677a1e5122f02b70322bbe42',1,'nem_sdk_interface::tagNEMeetingInfo::userList()'],['../structnem__sdk__interface_1_1tag_n_e_meeting_role_configuration.html#a358685d00e1b3a5d679871c0bd37856b',1,'nem_sdk_interface::tagNEMeetingRoleConfiguration::userList()']]],
  ['username_751',['userName',['../structnem__sdk__interface_1_1tag_n_e_in_meeting_user_info.html#ad6e3d249f3eb80828768ea021ea536ad',1,'nem_sdk_interface::tagNEInMeetingUserInfo']]],
  ['username_752',['username',['../structnem__sdk__interface_1_1tag_account_info.html#aee86cfff2eb461227b5883cfaee5dbf2',1,'nem_sdk_interface::tagAccountInfo']]]
];
