var searchData=
[
  ['live_5faccess_5fapp_5ftoken_847',['LIVE_ACCESS_APP_TOKEN',['../namespacenem__sdk__interface.html#ac2a760d29e1855fc4243d7d4d9d1fcb1acc754d778c8baf5a19473c0148a10bd0',1,'nem_sdk_interface']]],
  ['live_5faccess_5fnormal_848',['LIVE_ACCESS_NORMAL',['../namespacenem__sdk__interface.html#ac2a760d29e1855fc4243d7d4d9d1fcb1ac1173c92481e8ea0d7817d3b23168087',1,'nem_sdk_interface']]],
  ['live_5faccess_5ftoken_849',['LIVE_ACCESS_TOKEN',['../namespacenem__sdk__interface.html#ac2a760d29e1855fc4243d7d4d9d1fcb1a976f468fea2b2a2eef793d450eb6c856',1,'nem_sdk_interface']]],
  ['localvideoresolution_5f1080p_850',['LocalVideoResolution_1080P',['../namespacenem__sdk__interface.html#abeb0ccc48e9d0db84e8a6885a7771f31a6fb9204e697b0e8ba605502a01df7abf',1,'nem_sdk_interface']]],
  ['localvideoresolution_5f480p_851',['LocalVideoResolution_480P',['../namespacenem__sdk__interface.html#abeb0ccc48e9d0db84e8a6885a7771f31a92cb725dbbf19c4c04a19958b3a38dc4',1,'nem_sdk_interface']]],
  ['localvideoresolution_5f720p_852',['LocalVideoResolution_720P',['../namespacenem__sdk__interface.html#abeb0ccc48e9d0db84e8a6885a7771f31a7878282e1986cdce8bbf153d03337be0',1,'nem_sdk_interface']]]
];
