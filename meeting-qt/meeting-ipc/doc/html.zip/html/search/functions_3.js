var searchData=
[
  ['feedback_535',['feedback',['../classnem__sdk__interface_1_1_n_e_feedback_service.html#adc44572dc5d6442ff410c9e17928bf01',1,'nem_sdk_interface::NEFeedbackService']]]
];
