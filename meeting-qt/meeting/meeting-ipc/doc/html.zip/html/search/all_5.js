var searchData=
[
  ['feedback_63',['feedback',['../classnem__sdk__interface_1_1_n_e_feedback_service.html#adc44572dc5d6442ff410c9e17928bf01',1,'nem_sdk_interface::NEFeedbackService']]],
  ['feedback_5fservice_2eh_64',['feedback_service.h',['../feedback__service_8h.html',1,'']]],
  ['feedbackservicelistener_65',['FeedbackServiceListener',['../classnem__sdk__interface_1_1_feedback_service_listener.html',1,'nem_sdk_interface']]],
  ['full_5fmore_5fmenu_5fitems_5f_66',['full_more_menu_items_',['../classnem__sdk__interface_1_1_n_e_meeting_options.html#aec93632b8f3f27e5c80bc38e96d826c2',1,'nem_sdk_interface::NEMeetingOptions']]],
  ['full_5ftoolbar_5fmenu_5fitems_5f_67',['full_toolbar_menu_items_',['../classnem__sdk__interface_1_1_n_e_meeting_options.html#a842abcd8c34bd8d7a33417882b5dda14',1,'nem_sdk_interface::NEMeetingOptions']]]
];
