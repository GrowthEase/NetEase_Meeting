var searchData=
[
  ['remotevideoresolution_813',['RemoteVideoResolution',['../namespacenem__sdk__interface.html#a2675cb3e058acb583bb2456c9dfacb92',1,'nem_sdk_interface']]]
];
