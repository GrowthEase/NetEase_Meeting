var searchData=
[
  ['callback_5finterface_2eh_25',['callback_interface.h',['../callback__interface_8h.html',1,'']]],
  ['cancelmeeting_26',['cancelMeeting',['../classnem__sdk__interface_1_1_n_e_pre_meeting_service.html#a8691ce6093a38b97b2f85dbb12d42646',1,'nem_sdk_interface::NEPreMeetingService']]],
  ['chatroomconfig_27',['chatroomConfig',['../classnem__sdk__interface_1_1_n_e_meeting_options.html#abacffcb1df1e245ce3add2436f4f23a1',1,'nem_sdk_interface::NEMeetingOptions']]],
  ['cloudrecordon_28',['cloudRecordOn',['../structnem__sdk__interface_1_1tag_n_e_meeting_item_setting.html#ac5f59bd0f32a16ead66e9ac476a67803',1,'nem_sdk_interface::tagNEMeetingItemSetting']]],
  ['code_29',['code',['../structnem__sdk__interface_1_1tag_n_e_meeting_scene.html#a5e04ab0365dad3f5ea8ac38f4438fbde',1,'nem_sdk_interface::tagNEMeetingScene']]],
  ['cohost_30',['cohost',['../namespacenem__sdk__interface.html#a1a43eecc5d050c11ce8a9b7e05f4d79eaac6b68890511b6ae8658f7fd0638b312',1,'nem_sdk_interface']]],
  ['controller_5fdefine_2eh_31',['controller_define.h',['../controller__define_8h.html',1,'']]],
  ['controls_32',['controls',['../classnem__sdk__interface_1_1_n_e_start_meeting_params.html#a376929ffafc0015c56885abafa498e75',1,'nem_sdk_interface::NEStartMeetingParams::controls()'],['../structnem__sdk__interface_1_1tag_n_e_meeting_item_setting.html#a779fffe5d59cdbcfc0a5c407acb9ea8d',1,'nem_sdk_interface::tagNEMeetingItemSetting::controls()']]],
  ['createschedulemeetingitem_33',['createScheduleMeetingItem',['../classnem__sdk__interface_1_1_n_e_pre_meeting_service.html#a1f75c0b8aa464d8ac16963536acdb3c6',1,'nem_sdk_interface::NEPreMeetingService']]],
  ['createtime_34',['createTime',['../structnem__sdk__interface_1_1tag_n_e_meeting_item.html#a6f2ab7310984fc82ee546122016235a9',1,'nem_sdk_interface::tagNEMeetingItem']]]
];
