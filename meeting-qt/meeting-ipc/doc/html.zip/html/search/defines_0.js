var searchData=
[
  ['nem_5fmore_5fmenu_5fuser_5findex_907',['NEM_MORE_MENU_USER_INDEX',['../meeting_8h.html#a69754c6782bf9a7161cec24f36eb85e6',1,'meeting.h']]],
  ['nem_5fsdk_5finterface_5fexport_908',['NEM_SDK_INTERFACE_EXPORT',['../nemeeting__sdk__interface__export_8h.html#a49bb450b054cce5c9000b2a029403851',1,'nemeeting_sdk_interface_export.h']]],
  ['nem_5fsdk_5finterface_5fexport_5fprivate_909',['NEM_SDK_INTERFACE_EXPORT_PRIVATE',['../nemeeting__sdk__interface__export_8h.html#a274b9e88f7ce0825f01f36a65f5181a6',1,'nemeeting_sdk_interface_export.h']]],
  ['nnem_5fsdk_5finterface_5fbegin_5fdecls_910',['NNEM_SDK_INTERFACE_BEGIN_DECLS',['../build__config_8h.html#a3b8bd0abb315cddac95fc1618a08b3f2',1,'build_config.h']]],
  ['nnem_5fsdk_5finterface_5fend_5fdecls_911',['NNEM_SDK_INTERFACE_END_DECLS',['../build__config_8h.html#afe70f582596ac89529c8608119c585e6',1,'build_config.h']]],
  ['ns_5fi_5fnem_5fsdk_912',['NS_I_NEM_SDK',['../build__config_8h.html#a2feb16c9443da5ba4bc75ed5104a9b65',1,'build_config.h']]]
];
