var searchData=
[
  ['productname_623',['ProductName',['../classnem__sdk__interface_1_1_n_e_m_app_info.html#a1065f504ea2bb041f4bb7287794c0ba4',1,'nem_sdk_interface::NEMAppInfo::ProductName() const'],['../classnem__sdk__interface_1_1_n_e_m_app_info.html#a8ba6edb3c8de0a287556809355892f25',1,'nem_sdk_interface::NEMAppInfo::ProductName(const std::string &amp;product_name)']]]
];
