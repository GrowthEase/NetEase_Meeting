var searchData=
[
  ['cancelmeeting_529',['cancelMeeting',['../classnem__sdk__interface_1_1_n_e_pre_meeting_service.html#a8691ce6093a38b97b2f85dbb12d42646',1,'nem_sdk_interface::NEPreMeetingService']]],
  ['createschedulemeetingitem_530',['createScheduleMeetingItem',['../classnem__sdk__interface_1_1_n_e_pre_meeting_service.html#a1f75c0b8aa464d8ac16963536acdb3c6',1,'nem_sdk_interface::NEPreMeetingService']]]
];
