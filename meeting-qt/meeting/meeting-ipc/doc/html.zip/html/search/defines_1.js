var searchData=
[
  ['using_5fns_5fnnem_5fsdk_5finterface_981',['USING_NS_NNEM_SDK_INTERFACE',['../build__config_8h.html#ae0f492f37229a40a404e8108e0903fed',1,'build_config.h']]]
];
