var searchData=
[
  ['error_5fcode_5fcancelled_877',['ERROR_CODE_CANCELLED',['../namespacenem__sdk__interface.html#a7328a07f46550e029c47134fbdf2bbf2a8d3f2d50e33f3c103fba930b357e6202',1,'nem_sdk_interface']]],
  ['error_5fcode_5ffailed_878',['ERROR_CODE_FAILED',['../namespacenem__sdk__interface.html#a7328a07f46550e029c47134fbdf2bbf2a8b6cb71f1df2ed76ecbe17c17bdd2bb7',1,'nem_sdk_interface']]],
  ['error_5fcode_5fmeeting_5fpassword_5ferror_879',['ERROR_CODE_MEETING_PASSWORD_ERROR',['../namespacenem__sdk__interface.html#a7328a07f46550e029c47134fbdf2bbf2aa9bda9ca903d89bc9293a298d43ce6f5',1,'nem_sdk_interface']]],
  ['error_5fcode_5fno_5fauth_880',['ERROR_CODE_NO_AUTH',['../namespacenem__sdk__interface.html#a7328a07f46550e029c47134fbdf2bbf2a55ed32541e428e7de996d662c8046873',1,'nem_sdk_interface']]],
  ['error_5fcode_5fnot_5fimplemented_881',['ERROR_CODE_NOT_IMPLEMENTED',['../namespacenem__sdk__interface.html#a7328a07f46550e029c47134fbdf2bbf2a4d3e814b781b6ee5767cc3c28a15d32d',1,'nem_sdk_interface']]],
  ['error_5fcode_5fsdk_5fservice_5fnotsupport_882',['ERROR_CODE_SDK_SERVICE_NOTSUPPORT',['../namespacenem__sdk__interface.html#a7328a07f46550e029c47134fbdf2bbf2afcfe823af10118d13819ef9d7234ad34',1,'nem_sdk_interface']]],
  ['error_5fcode_5fsdk_5funinitialize_883',['ERROR_CODE_SDK_UNINITIALIZE',['../namespacenem__sdk__interface.html#a7328a07f46550e029c47134fbdf2bbf2a7449427f31b9157cd5204ba463743cc9',1,'nem_sdk_interface']]],
  ['error_5fcode_5fsuccess_884',['ERROR_CODE_SUCCESS',['../namespacenem__sdk__interface.html#a7328a07f46550e029c47134fbdf2bbf2acad2f6eb2f8ad216702d9edcd7fc9ee1',1,'nem_sdk_interface']]],
  ['error_5fcode_5funexpected_885',['ERROR_CODE_UNEXPECTED',['../namespacenem__sdk__interface.html#a7328a07f46550e029c47134fbdf2bbf2a0af510ce3d4b165d6ac4b250443d3ca6',1,'nem_sdk_interface']]]
];
