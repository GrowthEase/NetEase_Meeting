var searchData=
[
  ['registerschedulemeetingstatuslistener_668',['registerScheduleMeetingStatusListener',['../classnem__sdk__interface_1_1_n_e_pre_meeting_service.html#aefd12c562778712293f1f2218aa40312',1,'nem_sdk_interface::NEPreMeetingService']]],
  ['removeauthlistener_669',['removeAuthListener',['../classnem__sdk__interface_1_1_n_e_auth_service.html#a5b5d3dca57f19b989272108fc0185895',1,'nem_sdk_interface::NEAuthService']]]
];
