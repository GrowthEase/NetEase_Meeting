var searchData=
[
  ['settingchangtype_870',['SettingChangType',['../namespacenem__sdk__interface.html#aa501e41fc5b939266bb612c954c17ab9',1,'nem_sdk_interface']]]
];
