var searchData=
[
  ['live_5faccess_5fapp_5ftoken_908',['LIVE_ACCESS_APP_TOKEN',['../namespacenem__sdk__interface.html#ac2a760d29e1855fc4243d7d4d9d1fcb1acc754d778c8baf5a19473c0148a10bd0',1,'nem_sdk_interface']]],
  ['live_5faccess_5fnormal_909',['LIVE_ACCESS_NORMAL',['../namespacenem__sdk__interface.html#ac2a760d29e1855fc4243d7d4d9d1fcb1ac1173c92481e8ea0d7817d3b23168087',1,'nem_sdk_interface']]],
  ['live_5faccess_5ftoken_910',['LIVE_ACCESS_TOKEN',['../namespacenem__sdk__interface.html#ac2a760d29e1855fc4243d7d4d9d1fcb1a976f468fea2b2a2eef793d450eb6c856',1,'nem_sdk_interface']]],
  ['localvideoframeratefps_5f10_911',['LocalVideoFramerateFps_10',['../namespacenem__sdk__interface.html#a723d279ab87b6c6690cc1b186b0fc148ac3157b39fb0a92d40c845c312c085af1',1,'nem_sdk_interface']]],
  ['localvideoframeratefps_5f15_912',['LocalVideoFramerateFps_15',['../namespacenem__sdk__interface.html#a723d279ab87b6c6690cc1b186b0fc148ae59b6df9608cd01c9d93a6f79f4bfbb1',1,'nem_sdk_interface']]],
  ['localvideoframeratefps_5f24_913',['LocalVideoFramerateFps_24',['../namespacenem__sdk__interface.html#a723d279ab87b6c6690cc1b186b0fc148aa753677f186bdb3f9d8c44dd54294d3f',1,'nem_sdk_interface']]],
  ['localvideoframeratefps_5f30_914',['LocalVideoFramerateFps_30',['../namespacenem__sdk__interface.html#a723d279ab87b6c6690cc1b186b0fc148af53e09cc919a048cfd7bd80b36876df2',1,'nem_sdk_interface']]],
  ['localvideoframeratefps_5f60_915',['LocalVideoFramerateFps_60',['../namespacenem__sdk__interface.html#a723d279ab87b6c6690cc1b186b0fc148af50c20cd7ffd6490fe08a6e6cb246a01',1,'nem_sdk_interface']]],
  ['localvideoframeratefps_5f7_916',['LocalVideoFramerateFps_7',['../namespacenem__sdk__interface.html#a723d279ab87b6c6690cc1b186b0fc148a72d2af85389d3ca7cd6ff2c372decb52',1,'nem_sdk_interface']]],
  ['localvideoframeratefpsdefault_917',['LocalVideoFramerateFpsDefault',['../namespacenem__sdk__interface.html#a723d279ab87b6c6690cc1b186b0fc148abb906181a88c9602b2a87edff84a95af',1,'nem_sdk_interface']]],
  ['localvideoresolution_5f1080p_918',['LocalVideoResolution_1080P',['../namespacenem__sdk__interface.html#abeb0ccc48e9d0db84e8a6885a7771f31a6fb9204e697b0e8ba605502a01df7abf',1,'nem_sdk_interface']]],
  ['localvideoresolution_5f480p_919',['LocalVideoResolution_480P',['../namespacenem__sdk__interface.html#abeb0ccc48e9d0db84e8a6885a7771f31a92cb725dbbf19c4c04a19958b3a38dc4',1,'nem_sdk_interface']]],
  ['localvideoresolution_5f720p_920',['LocalVideoResolution_720P',['../namespacenem__sdk__interface.html#abeb0ccc48e9d0db84e8a6885a7771f31a7878282e1986cdce8bbf153d03337be0',1,'nem_sdk_interface']]]
];
