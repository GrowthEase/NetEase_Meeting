var searchData=
[
  ['tagnemeetinglanguage_871',['tagNEMeetingLanguage',['../namespacenem__sdk__interface.html#a826f9e7129056a2ff6a5f03b50500283',1,'nem_sdk_interface']]]
];
