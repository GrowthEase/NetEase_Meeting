var searchData=
[
  ['querykitversion_380',['queryKitVersion',['../classnem__sdk__interface_1_1_n_e_meeting_kit.html#a9ace78b5b120ed759b439b9576e2f959',1,'nem_sdk_interface::NEMeetingKit']]]
];
