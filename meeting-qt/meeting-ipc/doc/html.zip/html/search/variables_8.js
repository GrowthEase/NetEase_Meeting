var searchData=
[
  ['kcameramenuid_695',['kCameraMenuId',['../namespacenem__sdk__interface.html#a20a3a192be9020ebc8df1c663d0031df',1,'nem_sdk_interface']]],
  ['kchatmenuid_696',['kChatMenuId',['../namespacenem__sdk__interface.html#aa3658127231f8ce2d2a1870d7eba7696',1,'nem_sdk_interface']]],
  ['kfirstinjectedmenuid_697',['kFirstinjectedMenuId',['../namespacenem__sdk__interface.html#a582786b55486df324990c1feb7597dcd',1,'nem_sdk_interface']]],
  ['kinvitemenuid_698',['kInviteMenuId',['../namespacenem__sdk__interface.html#a5be5df7caa1d7704cdcefeefdc353fc0',1,'nem_sdk_interface']]],
  ['kmangeparticipantsmenuid_699',['kMangeParticipantsMenuId',['../namespacenem__sdk__interface.html#a8a9b5596d50abc7cc86c8d27d3a6e7ef',1,'nem_sdk_interface']]],
  ['kmicmenuid_700',['kMicMenuId',['../namespacenem__sdk__interface.html#a445a1e80c41c6be7e4203429540dcb02',1,'nem_sdk_interface']]],
  ['kparticipantsmenuid_701',['kParticipantsMenuId',['../namespacenem__sdk__interface.html#a78a7985d42ba6507a3044cf73567ac7b',1,'nem_sdk_interface']]],
  ['kscreensharemenuid_702',['kScreenShareMenuId',['../namespacenem__sdk__interface.html#a73865c98e16fc162ef3c402e9db66891',1,'nem_sdk_interface']]],
  ['kviewmenuid_703',['kViewMenuId',['../namespacenem__sdk__interface.html#a56aef10f6947a48750371ae9f868a3b3',1,'nem_sdk_interface']]],
  ['kwhiteboardmenuid_704',['kWhiteboardMenuId',['../namespacenem__sdk__interface.html#a01d3c81ff7b82fabebbbd87e3b1d51aa',1,'nem_sdk_interface']]]
];
